#!/bin/bash
if [ $# -le 0 ] 
then
    echo "chname name."
    exit
fi
for i in `ls`
do
    mv $i $1-$i
done
mkdir -p thesisuse
for i in mean mean2 mean4 mean6 mean8 mean10 rstd rstd2 rstd4 rstd6 rstd8 rstd10
do
    mv *$i-*.pdf thesisuse
done
mv $1-chname.sh chname.sh
