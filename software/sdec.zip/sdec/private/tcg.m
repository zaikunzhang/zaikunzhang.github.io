function [ s, value, msg, k, gplus, interior ] = tcg (g, H, delta,  kmax, epsi);
% Example:
% Gratton Zhang 2017
% H=diag([1 2 3]);
% g = [1;1;1]; delta=20; kmax=10; epsi=1e-6;
% [ s, msg, k, value, gplus, interior ] = tcg (g, H, delta,  kmax, epsi);
% delta = 1;
% [ s, msg, k, value, gplus, interior ] = tcg (g, H, delta,  kmax, epsi);
%
% Initializations
%
value = 0;

ng0 = norm(g);

%  Define TCG adapt

% example of termination rule  
 eps_term = epsi * ng0  ;
 eps_term = min( epsi, sqrt( ng0 ) ) * ng0  ;

s  = 0*g;
v  =  g ;
p  =  -v;
%
for k = 1:kmax
   Hp    = H * p;
   kappa = p' * Hp;

   % Check if negative curvature encountered

   if ( kappa <= 0 )
      sigma    = boundary_pt( s, p, delta);
      s        = s + sigma * p;
      msg      = [ 'st_tcg - negative curvature - ', int2str(k), ' iterations' ];
      value    = value - sigma * g' * p - 0.5 * sigma^2 * kappa;
      gplus    = g + sigma * Hp;
      interior = 0;
      return
   end

   gv    = g' * v;
   alpha = gv / kappa;

   % Check if outside the trust region
   if ( ( norm( s+alpha*p) ) >= delta )
      sigma    = boundary_pt( s, p, delta );
      s        = s + sigma * p;
      msg      = [ 'st_tcg - solution on the boundary - ', int2str(k), ' iterations '];
      value    = value - sigma * g' * p - 0.5 * sigma^2 * kappa;
      gplus    = g + sigma * Hp;
      interior = 0;
      return
   end
%
%  CG body
%

   s      = s + alpha * p;
   value  = value + 0.5 * alpha * gv; 
   gplus  = g + alpha * Hp;
   vplus  =  gplus ;
   gpvp   = gplus' * vplus;
   beta   = gpvp / gv;
   p      = -vplus + beta * p;
   g      = gplus;
   v      = vplus;

%  termination ?
            
   ngplus = sqrt( gpvp );
   if  ( ngplus < eps_term )
      msg=[ 'st_tcg - interior solution - ', int2str(k), ' iterations' ];
      interior = 1;
      return
   end
end
msg=['st_tcg - no solution in ',int2str(k),' iterations'];
interior = 1;

function sigma = boundary_pt( s, p, delta );
if delta ==0
  sigma = 0;
else
   np2   = p' * p;
   ns2  = s' * s;
   smp   = s' * p;
   sigma =(-smp+sqrt(smp^2+np2*(delta^2-ns2)))/(np2);
end
