function [x, f, exitflag, output] = fminsearch_4test(fun, x0, options)

if (~exist('fminsearch'))
    warning('fminsearch seems unavailable on your computer. Forget about testing it.');
    x = x0;
    f = feval(x0);
else
    tol = options.rhoend;
    maxfun = options.maxfun;
    fminsearch_options = optimset('MaxFunEvals', maxfun, 'TolFun', tol, 'TolX', tol, 'Display', 'none');  
    [x, f, exitflag, output] = fminsearch(fun, x0, options);
end
return;
