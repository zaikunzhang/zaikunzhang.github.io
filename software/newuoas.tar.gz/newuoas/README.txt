A Short Manual for NEWUOA, NEWUOAs, and some Scripts to Test DFO Solvers 

# This version is not intended to be released. 
#
# Notice that only unconstrained optimization is concerned in this document.
#
# All rights reserved. 
#
# ZHANG Zaikun, 23/08/2016, zaikun.zhang@polyu.edu.hk
# Department of Applied Mathematics, The Hong Kong Polytechnic University

---------------------------------------------------------------------------
0. Before starting, run in Bash
$ make
to mexify NEWUOA and some testing scripts.  

If nothing strange happens, then try the following command in MATLAB. 

>> frec = testalg('newuoa', 'chrosen', 20); 

If nothing strange happens either, then you can play with more examples
in Section 2.1 below. If strange things already occur, write to me after
reading the following.  

Important notes: 
0.1. For the moment, only *nix platforms are considered. Sorry, Windows users. We will take care of Windows later.
0.2. You may receive the following error message

"mex: option '-output' is ambiguous; possibilities: '--output-comment' '--output-directory' '--output-format'
This is pdfTeX, Version 3.14159265-2.6-1.40.16 (TeX Live 2015/Debian) (preloaded format=mex)
 restricted \write18 enabled.
entering extended mode
! I can't find file `newuoa_mex'." 

Don't Panic. This is because the "mex" command in your system is the
pdfTeX mex rather than the MATLAB mex. You need to modify the Makefile
to specify where your MATLAB mex is located on your computer. 
This will be taken care of automatically in later versions. 

---------------------------------------------------------------------------
1. After running "make", the syntax of calling NEWUOA is identical to
   that of the MATLAB built-in functions fminunc and fminsearch, i.e.,
>> [xopt, fopt, exitflag, output] = newuoa(fun, x0, options); % "options" is optional 

f ---  the function handle, 
x0 --- the starting point x0

Several parameters can be specified by the optional structure variable 
"options", and the following ones are critical:

rhobeg --- the initial step size (should be the rough scale of ||x0-x_optimal||, built-in default value: 1)
rhoend --- the final step size (should be the desired precision, built-in default value: 1e-6)
maxfun --- the budget of function evaluations (built-in default value: 100*n)
npt --- the number of interpolation points for each quadratic model (built-in default and RECOMMENDED value: 2*n+1)

See the code for other options. 

NEWUOA has four outputs whose names are self-explanatory.

The syntax of calling NEWUOAs is the same, i.e., 

>> [xopt, fopt, exitflag, output] = newuoas(fun, x0, options); % "options" is optional 

Notice that this syntax is identical to that of the MATLAB built-in
functions fminunc and fminsearch.

---------------------------------------------------------------------------
2. To test one particular problem, use TESTALG, whose syntax is

>> frec = testalg(solver, problem, dimension, options);

solver --- solver name (string or function handle)
problem --- problem name (string, see Section 2.2 below for details)
dimension --- the dimension of the problem
frec --- an array recording the function values evaluated during the test

"options" is an optional variable that allows us to enforce
noise/inexactness or nonsmooth regularization to the objective function.

2.1. Examples

a. Test NEWUOA on the chrosen problem (Chained-Rosenbrock) with dimension 20. 

>> frec = testalg('newuoa', 'chrosen', 20);

b. Test NEWUOA on the chrosen problem with Gaussian noise level 1e-3.

>> options1.noise = 1e-3;
>> frec = testalg('newuoa', 'chrosen', 20, options1);
(Since there is randomness, it will perform 10 random runs by default)

c. Test NEWUOA on the chrosen problem, and the function values are
accurate only up to 3 significant digits.

>> options2.signif = 3;
>> frec = testalg('newuoa', 'chrosen', 20, options2);

d. Test NEWUOA on the chrosen problem with an L-0.5 norm regularization, i.e.

chrosen + lambda*||x||_{0.5}^{0.5}    (default value for lambda is 10)

>> options3.regul = 0.5; 
>> frec = testalg('newuoa', 'chrosen', 20, options3);

For sure, it is not a good idea to regard a nonsmooth regularized
problem as a black box. We test them only for understanding how the
algorithms will behave when there is nonsmoothness. 

e. Test NEWUOA on the chrosen problem with random starting points.

>> options4.randomizex0 = 1; 
>> frec = testalg('newuoa', 'chrosen', 20, options4);
(it will perform 10 random runs by default)

f. It is possible to combine different options. For instance: 

>> options.signif = 3; options.regul = 0.5; 
>> frec = testalg('newuoa', 'chrosen', 20, options); 

This would mean to test NEWUOA on  

chrosen + 10*||x||_{0.5}^{0.5}, 

whose function value is truncated to the first three significant digits.

2.2 How do we know which problem is available for testing? 
There names are listed in the "problems" file. The function values are
computed by evalfun.f (mexified to evalfun.mexXXX). Currently, evalfun.f
contains 96 CUTEr problems (or variants), and it is possible to add more.  

2.3 What if we want to test multiple problems? 
List the names of the problems in the "problems" file, and then replace
'chrosen' in the previous commands by 'ALL'.

2.4 What if we want to test another algorithm, say, alg?
Wrap alg so that it can be called with the following syntax 

>> alg(fun, x0, options);
(the same syntax as fminunc, fminsearch, NEWUOA, and NEWUOAs)

Then run

>> testalg(problem, 'alg', dimension, options);

See fminunc_4test.m and fminsearch_4test.m for examples. 

2.5 What if we want to test multiple algorithms?
List the names of the problems in the "solvers" file, and then replace
'alg' in the previous command by 'ALL'.

2.6 Of course, you can try

>> testalg('ALL', 'ALL', dimension, options);

***2.7*** It is quite interesting to test solvers on problems with
noisy/truncated function values and/or nonsmooth regularizations.
On one hand, solvers good at smooth problems do not necessarily behave
well on these problems. On the other hand, amazingly, it turns out
that some solvers can solve some (toy) problems to very high precision
based on only 3 significant digits of the function values.
It also provides us an opportunity to check the validity of some common
beliefs (e.g.  direct search is more stable than model-based methods).  
Try it.

---------------------------------------------------------------------------
3. To plot performance/data profiles, use PERFDATA.

3.1 For example,

>> perfdata(30, 'plain');

will plot the performance and data profiles of all the algorithms listed in
the "solvers" file, using the test problems listed in the "problems"
file. 30 is the dimension of the problems, and 'plain' means that no
noise or nonsmoothness will be enforced to the objective function, and
the starting point will not be perturbed. 

The figures are saved in ./results

3.2  Generally, "perfdata" can be called as

>> perfdata(n, feature, options);

where n is the dimension of the problems, and "feature" is a string that
specifies the feature of the test, possible cases being

'Lq' --- L-1/2 regularization ("q" for "quarter")
'Lh' --- L-1/2 regularization ("h" for "half")
'L1' --- L1 regularization
'noisy' --- noisy objective function (default noise level is 1e-3)
's' --- single precision objective function
'signif3' --- function value is accurate only up to 3 significant digits 
('signif1', 'signif2', ..., 'signif8' are all acceptable)
'randomx0' --- randomly perturbed starting point
any other --- plain test without any of the above features 

For the moment, only one feature can be specified. 

"options" is an optional structure to specify the noise level, number of
random runs etc. See the code for details. Omitting it is totally fine. 
